import React,{componet} from "react";
class Car extends React.Component {
    constructor()
    {
        super();
        this.state={color:"red",name:"audi",price:3500000}
        
    }

    render()
    {
        return <h2>I am a {this.state.name} car! and <br/> my color is :{this.state.color}<br/> price is:{this.state.price}</h2>
    }
}

export default Car