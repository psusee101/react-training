import React from 'react';
import ReactDOM from 'react-dom/client';
// function Car(props){
//   return<h2>I am a {props.brand.model}</h2>;
// }

// function Garage()
// {
//   const carInfo={name:"Ford",model:"Mustag"}
//   return(
//     <>
//     <h1>Who lives in my garage?</h1>
//     <Car brand={carInfo}/>
//     </>
//   );
// }

// function Garage(props)
// {
//   const cars=props.cars;
//   return(
//     <>
//     <h1>Garage</h1>
//     {cars.length > 0 && <h2>You have {cars.length} cars in ur garage.</h2>}
//     </>
//   )
// }


function Football()
{
  const shoot = () =>{
    alert("great shot")
  }

  return(
    <button onClick={shoot}>Take the shot!</button>
  )
}

function MissedGoal()
{
  return <h1>MISSED!</h1>
}

function MadeGoal()
{
  return <h1>GOAL!</h1>
}

function Goal(props)
{
  const isGoal = props.isGoal;
  return(
    <>
    {isGoal ? <MadeGoal/> : <MissedGoal/>}
    </>
  )
  // if(isGoal)
  // {
  //   return <MadeGoal/>

  // }
  // return <MissedGoal/>
}
function Car(props)
{
  return <li>I am a {props.brand}</li>
}
function ListDemo()
{
  // const cars=['Ford','BMW','Audi','hundai','Honda'];

  const cars=[
    {id:1,brand:'Ford'},
    {id:2,brand:'BMW'},
    {id:3,brand:'Audi'}
  ]
  return(
    <>
    <h1>List component</h1>
    <ul>
      {cars.map((car)=> <Car key={car.id} brand={car.brand}/>)}
    </ul>
    </>
  )
}
const root =ReactDOM.createRoot(document.getElementById('root'))
root.render([<Football />,<Goal isGoal={false}/> ,<ListDemo />]);