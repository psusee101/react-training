import React,{Component} from 'react';
import './App.css';
import './employee'
import Employee from './employee';
import Car from './Car'

class App extends React.Component
{
  render(){
    return(
      <div>
        <h1>Parent Component</h1>
        <Product/>
        <Employee/>
        <Car/>
      </div>
    )
  }
}

class Product extends React.Component
{
  render()
  {
    return(
      <div>
        <h1>Product Componet</h1>
        <table border="2">
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Price</th>
          </tr>
          <tr>
            <td>111</td>
            <td>Pen</td>
            <td>500</td>
          </tr>
          <tr>
            <td>112</td>
            <td>Books</td>
            <td>2500</td>
          </tr>
        </table>
      </div>
    )
  }
}
export default App;