import React,{Component} from 'react'

class Home extends React.Component
{
    render()
    {
        return(
            <>
            Home Page
            </>
        )
    }
}

export default Home