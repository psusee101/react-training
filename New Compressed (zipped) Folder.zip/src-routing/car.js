import styles from './my-style.module.css'

const Car = () =>{
    return <h1 className={styles.bigblue}>Hello Car!</h1>
}

export default Car;
