import React,{Component} from 'react'

class About extends React.Component
{
    render()
    {
        return(
            <>
            About Page
            </>
        )
    }
}

export default About