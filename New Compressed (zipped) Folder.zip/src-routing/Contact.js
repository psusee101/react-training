import React,{Component} from 'react'

class Contact extends React.Component
{
    render()
    {
        return(
            <>
            contact Page
            </>
        )
    }
}

export default Contact