// import ReactDOM from "react-dom/client";
// import { BrowserRouter, Routes, Route } from "react-router-dom";

// import Home from "./Home";
// import About from "./About"
// import Contact from "./Contact";



// export default function App() {
//   return (
//     <BrowserRouter>
//       <Routes>
//       <Route exact path='/' element={< Home />}></Route>
//      <Route exact path='/about' element={< About />}></Route>
//     <Route exact path='/contact' element={< Contact />}></Route>

//       </Routes>
//     </BrowserRouter>
//   );
// }

// const root = ReactDOM.createRoot(document.getElementById('root'));
// // root.render(<App />);
// import React from 'react';
// import ReactDOM from 'react-dom';
// import App from './eample';

// ReactDOM.render(
// <App />,
// document.getElementById('root')
// );

import {useState,useEffect} from 'react'
import ReactDOM  from 'react-dom/client'
import Todos from './Todos'
import Car from './car.js';

const App=()=>{
    const [count,setCount]=useState(0)
    const [todos,setTodos]=useState(["todo 1","todo 2"]);


const increment= () =>{
    setCount((c)=>c+1);
};

return(
    <>
    <Todos todos={todos} />
    <hr />
    <div>
        Count:{count}
        <button onClick={increment}>+</button>
    </div>
    </>
)
}

const Header= () =>{
    return(
        <>
        <h1 style={{backgroundColor:"green",color:"red",fontSize:"30px"}}>Hello World</h1>
        <p>add a little style</p>
        </>
    )
}

function Favoritecolor()
{
    const [color,setcolor]=useState("red");
    return(
        <>
        <h1>My faourite color is {color}!</h1>
        <button type="button" onClick={()=>setcolor("blue")}>Blue</button>
        <button type="button" onClick={()=>setcolor("red")}>Red</button>
        <button type="button" onClick={()=>setcolor("Pink")}>Pink</button>
        <button type="button" onClick={()=>setcolor("Green")}>Blue</button>
        </>
    )
}

function Car1()
{
    const [brand,setBrand]=useState("Ford");
    const [model,setModel]=useState("Mustag");
    const [year,setYear]=useState("2022");
    const [color,setcolor]=useState("red");

    return(
        <>
        <h1>my {brand}</h1>
        <p>It is a {color} {model} from {year} </p>
        </>
    )
}

function Emp()
{
    const [emp,setEmp]=useState({
        name:"Mugil",
        age:"25",
        department:"evelopment",
        salary:"50000",
        city:"Chennai"
    });
    const updateSalary=()=>{
        setEmp(previousState=>{
            return {...previousState,salary:"65000"}  })
    }
    return(
        <>
        <h1>my {emp.name}</h1>
        <p>my age is {emp.age} belongs to {emp.department} and i am getting the salary of  
        {emp.salary}  and i am from {emp.city}</p>
        <button type="button" onClick={updateSalary}>New Salary</button>
        </>
    )
}

function Timer()
{
    const[count,setCount]=useState(0);

    useEffect(()=>{
        setTimeout(()=>{
            setCount((count)=>count+1);
        },1000)
    });

    return <h1>I have rendered {count} times!</h1>
}

function Counter(){
    const[count,setCount]=useState(0);
    const[calculation,setCalculation]=useState(0)

    useEffect(()=>{
        setCalculation(()=>count*2);
    },[count]);
    return(
        <>
        <p>Count:{count}</p>
        <button onClick={()=>setCount((c)=>c+1)}>+</button>
        <p>Calculation:{calculation}</p>
        </>
    )
}

const root=ReactDOM.createRoot(document.getElementById('root'));
root.render([<App />,<Header />,<Car />,<Favoritecolor />,<Car1 />,<Emp />,<Timer />,<Counter />])