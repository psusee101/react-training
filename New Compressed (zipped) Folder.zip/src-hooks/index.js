import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

import reportWebVitals from './reportWebVitals';
import { useState,useRef,useEffect } from 'react';

function App()
{
  const[inputValue,setInputValue]=useState("");
  const count=useRef(0);

  useEffect(()=>{
    count.current=count.current+1;
  })

  return(
    <>
    <input type="text" value={inputValue} onChange={(e)=>setInputValue(e.target.value)} />
    <h1>Render Count:{count.current}</h1>
    </>
  )
}
function Component1()
{
  const [user,setUser]=useState("Jesse Hall");
  return(
  <>
  <h1>{`Hello ${user}!`}</h1>
  <Component2 user={user}/>
  </>
  );
}

function Component2({user})
{
  return(
  <>
  <h1>component2</h1>
  <Component3 user={user}/>
  </>
  );
}

function Component3({user})
{
  return(
  <>
  <h1>component3</h1>
  <Component4 user={user}/>
  </>
  );
}

function Component4({user})
{
  return(
  <>
  <h1>component4</h1>
  <Component5 user={user}/>
  </>
  );
}
function Component5({user})
{
  return(
  <>
  <h1>Component5</h1>
  <h2>{`Hello ${user} again`}</h2>
  </>
  );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    [<App />,<Component1 />]
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
