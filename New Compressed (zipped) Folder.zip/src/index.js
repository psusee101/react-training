import React from 'react';
import {Route,Link,BrowserRouter as Router} from 'react-router-dom'
import  ReactDOM  from 'react-dom';

import './index.css';
import App from './App';
import About from './About';
import Contact from './contact';

import reportWebVitals from './reportWebVitals';

ReactDOM.render((
  <Router history = {browserHistory}>
     <Route path = "/" component = {App}>
        <IndexRoute component = {Home} />
        <Route path = "home" component = {Home} />
        <Route path = "about" component = {About} />
        <Route path = "contact" component = {Contact} />
     </Route>
  </Router>
), document.getElementById('app'))
