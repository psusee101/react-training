import React,{Componet} from 'react'
// class App extends React.Component
// {
//   constructor(props)
//   {
//     super(props);
//     this.updateSubmit= this.updateSubmit.bind(this);
//     this.input=React.createRef();

//     this.state={
//       personGoing:true,
//       numberOfPersons:5
//     };

//     this.handleInputChange=this.handleInputChange.bind(this);
//   }

//   handleInputChange(event)
//   {
//     const target = event.target;
//     const value=target.type==='checkbox'?target.checked:target.value;
//     const name=target.name;
//     this.setState({
//       [name]:value
//     })
//   }

//   updateSubmit(event)
//   {
//     alert("you have entered the username and password successfully");
//     event.preventDefault();
//   }

//   render()
//   {
//     return (
//       <div>
//         <form onSubmit={this.updateSubmit}>
//           <label>UserName:<input type="text" ref={this.input}/></label><br/><br/>
//           <label>password:<input type="password" ref={this.input}/></label><br/><br/>
//         <input type="submit" value="Submit"/>
//         </form>
//         <form>
//           <h1>Multiple input</h1>
//           <label>Is Person going:<input name="person going" type="checkbox" checked={this.state.personGoing}
//           onChange={this.handleInputChange}/></label><br/><br/>
//           <label>Number of persons:<input name="number of persons" type="number" value={this.state.numberOfPersons}
//           onChange={this.handleInputChange}/></label>
//         </form>
//       </div>
//     )
//   }
// }

import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, Link, browserHistory, IndexRoute } from 'react-router'

class App extends React.Component {
   render() {
      return (
         <div>
            <ul>
            <li>Home</li>
            <li>About</li>
            <li>Contact</li>
            </ul>
            {this.props.children}
         </div>
      )
   }
}

export default App